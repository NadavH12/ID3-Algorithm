import pandas as pd
import math


# method for querying the tree
# pass in query information and tree, iterates tree accordingly until leaf node is reached and returns predicted value
def classify(row, tree):
    if type(tree) is dict:
        for a in tree:
            # there is actually only one
            att = a

        subtrees = tree[att]
        value = row[att]

        return classify(row, subtrees[value])
    else:
        # tree is a leaf
        return tree


# method for calculating the accuracy of the model
# pass in test_data, target_attribute, and tree
# gets predicted value from tree for each test query
# compares to actual value and sums number of correct & wrong results
# returns accuracy ratio
def getAccuracy(test_data, target_attribute, tree):
    correct = 0
    wrong = 0

    # for all rows in the test data
    for ind, row in test_data.iterrows():
        if classify(row, tree) == row[target_attribute]:
            correct += 1
        else:
            wrong += 1

    print("correct_classification_count = ", correct)
    print("incorrect_classification_count = ", wrong)
    return correct / float(correct + wrong)


# Reads training data
# Returns training data as Dataframe
def getData():
    dataSetName = "census_training.csv"
    return pd.read_csv(dataSetName)


# Reads testing data
# Returns testing data as Dataframe
def getTestData():
    dataSetName = "census_training_test.csv"
    return pd.read_csv(dataSetName)


# count_classes returns a Series with the count of each of the target attribute values in the data
def count_classes(data, target_attribute):
    classes_only = data[target_attribute]
    return classes_only.value_counts()


# Helper method returns target value for leaf nodes
def id3_leaf(s):
    return s


# constructs and returns a dictionary representing an internal node
def id3_node(att, subtrees):
    # an internal node is a dict with single index - the attribute name
    # and the value is a dict of attribute values and their associated subtrees
    node = dict()
    node[att] = subtrees
    return node


# returns the entropy of the data set for the target atteribute
def entropy(data, target_attribute):
    att_only = data[target_attribute]
    probs = att_only.value_counts(normalize=True)
    ent = 0.0
    # for all probabilites
    for i, p in probs.items():
        ent += -p*math.log2(p)

    return ent


# returns a dictionary of the form {featureColumnName: information_gain}
def information_gain(data, unused_attributes, target_attribute):
    e = dict()
    h_s = entropy(data, target_attribute)
    rows_h_s = len(data)

    for att in unused_attributes:
        possible_values = unused_attributes[att]
        gain = h_s
        col = data[att]
        
        for v in possible_values:
                data_subset = data[col == v]
                rows_subset = len(data_subset)
                p = float(rows_subset) / rows_h_s
                gain -= entropy(data_subset, target_attribute) * p

        e[att] = gain

    return e


# The ID3 algorithm begins with an original set S as the root node.
# It calculates the information gain of the the unused attributes of S.
# It selects the attribute with the highest information gain.
# S is split by the selected attribute to produce subsets of the data.
# The algorithm then recurses on each subset, using the attributes that are left.
#
# Recursion on a subset may stop in one of these cases:
#
# - all elements in the subset belongs to the same class:
#       generate leaf  labelled with the class
# - there are no more attributes but the examples still do not belong to the same class.
#       generate leaf  with the most common class
# - there are no examples
#       generate leaf with the most common class of the examples in the parent node's set.
#
# The decision tree is constructed with each internal node representing the selected attribute on which the data was split,
# and leaf nodes representing the class label of the final subset of this branch.

# data is a pandas dataframe
# unused attribute is a dict of attribute to list of values
# parent_attribute and parent_largest_class are strings
# min_partition is used optionally for implementing tree pruning
def id3(data, unused_attributes, target_attribute, parent_largest_class, min_partition):
    # if there are no examples (or less examples than the manually set pruning minimum)
    # decide on common class of the examples in the parent node's set.
    if(data.shape[0] <= min_partition):
        return id3_leaf(parent_largest_class)

    class_counts = count_classes(data, target_attribute)
    largest_class = class_counts.index[0]

    # if all data belongs to the same class, decide on that class
    if(class_counts.count() == 1):
        return id3_leaf(class_counts.index[0])

    # Examples do not all belong to the same class.
    # If there are no unused attributes left decide on largest class
    if(len(unused_attributes) == 0):
        return id3_leaf(largest_class)

    # compute information gains
    gains = information_gain(data, unused_attributes, target_attribute)
    highest_gain_att = max(gains, key=gains.get)

    # build a new internal node
    subtrees = dict()

    # ok, we've chosen to split on highest_gain_att.
    # remove it from unused_attributes
    remaining_attributes = unused_attributes.copy()
    possible_values = remaining_attributes.pop(highest_gain_att)

    # Now we need to enumerate the possible values of the attribute and split the data
    # accordingly
    col = data[highest_gain_att]
    for v in possible_values:
        data_subset = data[col == v]
        subtrees[v] = id3(data_subset, remaining_attributes, target_attribute, largest_class, min_partition)

    return id3_node(highest_gain_att, subtrees)


def main():
    print("\n\nTraining and testing model without pruning:")
    data = getData()
    print("========== Training started on", data.shape[0], "examples")
    attributes = list(data.columns)

    target_attribute = attributes[-1]
    attributes = attributes[:-1]

    # unused attributies is a dict of attributes and possible values
    unused_attributes = dict()
    for att in attributes:
        unused_attributes[att] = data[att].unique()

    tree = id3(data, unused_attributes, target_attribute, None, 0)
    print("========== FINISHED training using training examples\n")
    
    print("========== TESTING STARTED\n")

    test_data = getTestData()
    print("Number of testing examples =", test_data.shape[0])
    accuracy = getAccuracy(test_data, target_attribute, tree)
    print("Accuracy =", 100 * accuracy, "%")
    print("========== TESTING ENDED\n\n\n")
    
    print("Training and testing model with pruning to a minimum partition size of 30:")
    data = getData()
    print("========== Training started on", data.shape[0], "examples")
    attributes = list(data.columns)

    target_attribute = attributes[-1]
    attributes = attributes[:-1]

    # unused attributies is a dict of attributes and possible values
    unused_attributes = dict()
    for att in attributes:
        unused_attributes[att] = data[att].unique()

    tree = id3(data, unused_attributes, target_attribute, None, 30)
    print("========== FINISHED training using training examples\n")
    
    print("========== TESTING STARTED\n")

    test_data = getTestData()
    print("Number of testing examples =", test_data.shape[0])
    accuracy = getAccuracy(test_data, target_attribute, tree)
    print("Accuracy =", 100 * accuracy, "%")
    print("========== TESTING ENDED\n\n\n")
    
    
if __name__ == "__main__":
    main()